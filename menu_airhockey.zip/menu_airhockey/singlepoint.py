import pygame, sys
mainClock = pygame.time.Clock()
from pygame.locals import*
pygame.init()

WINDOW_SIZE = pygame.display.get_desktop_sizes()[0]

WIN_WIDTH, WIN_HEIGHT = WINDOW_SIZE

pygame.display.set_caption('AirHockey')

screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)

BG = pygame.transform.scale(pygame.image.load("standard_background.png"), (WIN_WIDTH, WIN_HEIGHT))

font = pygame.font.SysFont(None, 30)

def draw_text(text,font,color,surface,x,y):
    textobj = font.render(text,1,color)
    textrect = textobj.get_rect()
    textrect.topleft = (x,y)
    surface.blit(textobj, textrect)


click = False


screen_width = screen.get_width()
screen_height = screen.get_height()

def point():
    run = True
    positie = [0,0]
    while run == True:
        screen.blit(BG, [0,0])
        draw_text('How many points?', font, (0,0,0), screen, 250, 40)
        mx, my = positie[0],positie[1]


        #buttons locatie/grootte
        button_5 = pygame.Rect(200,100,200,50)
        button_10 = pygame.Rect(200,180,200,50)
        button_15 = pygame.Rect(200,260,200,50)
        button_ex = pygame.Rect(200,340,200,50)

        #button kleur
        pygame.draw.rect(screen, (255,0,0), button_5)
        pygame.draw.rect(screen, (255,0,0), button_10)
        pygame.draw.rect(screen, (255,0,0), button_15)
        pygame.draw.rect(screen, (255,0,0), button_ex)

        #Tekst Button
        draw_text('5 punten', font,(255,255,255), screen, 203,115)
        draw_text('10 punten', font,(255,255,255), screen, 203,195)
        draw_text('15 punten', font,(255,255,255), screen, 203,275)
        draw_text('Back', font,(255,255,255), screen, 203,355)
        
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
            #click effecten
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_5.collidepoint(event.pos):
                        print("5 punten")
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_10.collidepoint(event.pos):
                        print("10 punten")
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_15.collidepoint(event.pos):
                        print("15 punten")
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_ex.collidepoint(event.pos):
                      return

        pygame.display.update()
        mainClock.tick(60)