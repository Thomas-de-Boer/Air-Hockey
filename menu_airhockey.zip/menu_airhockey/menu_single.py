import pygame, sys
from singlepoint import point
mainClock = pygame.time.Clock()
from pygame.locals import*
pygame.init()

WINDOW_SIZE = pygame.display.get_desktop_sizes()[0]

WIN_WIDTH, WIN_HEIGHT = WINDOW_SIZE

pygame.display.set_caption('AirHockey')

screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)

BG = pygame.transform.scale(pygame.image.load("standard_background.png"), (WIN_WIDTH, WIN_HEIGHT))

font = pygame.font.SysFont(None, 30)

def draw_text(text,font,color,surface,x,y):
    textobj = font.render(text,1,color)
    textrect = textobj.get_rect()
    textrect.topleft = (x,y)
    surface.blit(textobj, textrect)


click = False


screen_width = screen.get_width()
screen_height = screen.get_height()

def single():
    run = True
    positie = [0,0]
    while run == True:
        screen.blit(BG, [0,0])
        draw_text('SinglePlayer!', font, (0,0,0), screen, 250, 40)
        mx, my = positie[0],positie[1]


        #buttons locatie/grootte
        button_hard = pygame.Rect(200,100,200,50)
        button_normal = pygame.Rect(200,180,200,50)
        button_easy = pygame.Rect(200,260,200,50)
        button_ex = pygame.Rect(200,340,200,50)

        #button kleur
        pygame.draw.rect(screen, (255,0,0), button_hard)
        pygame.draw.rect(screen, (255,0,0), button_normal)
        pygame.draw.rect(screen, (255,0,0), button_easy)
        pygame.draw.rect(screen, (255,0,0), button_ex)

        #Tekst Button
        draw_text('Hard', font,(255,255,255), screen, 203,115)
        draw_text('Normal', font,(255,255,255), screen, 203,195)
        draw_text('Easy', font,(255,255,255), screen, 203,275)
        draw_text('Back', font,(255,255,255), screen, 203,355)
        
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
            #click effecten
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_hard.collidepoint(event.pos):
                        diff = "3"
                        point()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_normal.collidepoint(event.pos):
                        diff = "2"
                        point()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_easy.collidepoint(event.pos):
                        diff = "1"
                        point()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if button_ex.collidepoint(event.pos):
                      return

        pygame.display.update()
        mainClock.tick(60)